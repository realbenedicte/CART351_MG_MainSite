//server.js
//
//Sources/Resource:
//https://medium.com/@nitinpatel_20236/image-upload-via-nodejs-server-3fe7d3faa642

//Node Modules needed
const path = require('path');
const multer = require("multer"); //for storage purposes :)
const storage = multer.diskStorage({
  destination: function(req, file, cb) {//where we save the photo on our server :)
    cb(null, "uploads/images");
  },
  filename: function(req, file, cb) {
    cb(null, `photo-${makeid(5)}`); //use unique name for each photo taken :)
  },
});

const upload = multer({ //make sure to define our storage.
  storage: storage
});

const fs = require("fs");
let express = require("express");
const app = express();

const portNumber = 4200; //where we listen

let httpServer = require("http").createServer(app);
// create a server (using the Express framework object)
// declare io which mounts to our httpServer object (runs on top ... )
let io = require("socket.io")(httpServer);
// serving static files
let static = require("node-static"); // for serving static files (i.e. css,js,html...)

// sendFile will go here
app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '/index.html'));
});

//simple server via express which displays the contents of index.html file
//that is inside public directory.
app.use(express.static("public"));

// make server listen for incoming messages
httpServer.listen(portNumber, function() {
  console.log("listening on port:: " + portNumber);
});

//socket.io
//
//make sure its connected - each new user gets original id
io.on("connect", function(socket) {
  console.log("original id:: " + socket.id);
  try {
    // read contents of the file
    const data = fs.readFileSync('test.txt', 'UTF-8');
    // split the contents by new line
    const lines = data.split(/\r?\n/);
    // print all lines
    lines.forEach((line) => {
      console.log(line);
      if (line) {
        socket.emit('receivedFileData', line);
      }
    });
  } catch (err) {
    console.error(err);
  }
});


//file upload to server
//directory name was defined above and lives at /uploads/images
//takes field name image, and stores in uploads>Images
//upload -> multer
//callback has request and response object
app.post("/upload", upload.single("image"), (req, res) => {
  if (req.file) {
    res.json(req.file);
    //create imageObj, basically holds the path to where our image is on the server
    const imageObj = {
      "url": `/images/${req.file.filename}`
    };
    //append the imageObj to our test.txt file :)
    fs.appendFile('test.txt', JSON.stringify(imageObj) + "\n", function(err) {
      if (err) throw err;
      console.log('Saved!');
      io.sockets.emit('receivedFileData', JSON.stringify(imageObj)); //send to all sockets
    });
    console.log(req.file.filename);
  } else throw "error";
  res.sendStatus(200); //send back that everything went ok
});

//utility function to make a unique id for the photo taken on the website
function makeid(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() *
 charactersLength));
   }
   return result;
}
// serve anything from this dir ...
app.use(express.static(__dirname + "/public"));
// serve anything from this dir ...
app.use(express.static(__dirname + "/uploads"));
// for the client...
app.use(express.static(__dirname + "/node_modules"));
