//client.js
//
//resources:
// FILELIST
//https://developer.mozilla.org/en-US/docs/Web/API/FileList
//must have: <input id="fileItem" type="file">
//ex: The following line of code fetches the first file in the node's file list as a File object:
//var file = document.getElementById('fileItem').files[0];

//FormData.append()
//https://developer.mozilla.org/en-US/docs/Web/API/FormData/append

//GOT SOME HELP FROM HERE:
//https://stackoverflow.com/questions/60188877/how-to-send-captured-webcam-image-and-save-to-server-via-input-field

//global vars :)
let dataURL; //holds the image taken data!
var width = 320; // We will scale the photo width to this
var height = 0; // This will be computed based on the input stream
var streaming = false;
var video = null;
var canvas = null;
var photo = null;
var startbutton = null;

window.addEventListener('load', runApp, false); //when window loads run the app!

function runApp() {

  startup();
  //startup() starts up everything to do with taking a photo and canvas
  function startup() {
    video = document.getElementById('video');
    canvas = document.getElementById('canvas');
    photo = document.getElementById('photo');
    startbutton = document.getElementById('startbutton');
    navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false
      })
      .then(function(stream) {
        video.srcObject = stream;
        video.play();
      })
      .catch(function(err) {
        console.log("An error occurred: " + err);
      });

    video.addEventListener('canplay', function(ev) {
      if (!streaming) {
        height = video.videoHeight / (video.videoWidth / width);

        if (isNaN(height)) {
          height = width / (4 / 3);
        }
        video.setAttribute('width', width);
        video.setAttribute('height', height);
        canvas.setAttribute('width', width);
        canvas.setAttribute('height', height);
        streaming = true;
      }
    }, false);

    startbutton.addEventListener('click', function(ev) {
      takepicture();
      ev.preventDefault();
    }, false);
    clearphoto();
  }; //end of startup function :)

  //clear the photo
  function clearphoto() {
    var context = canvas.getContext('2d');
    context.fillStyle = "#AAA";
    context.fillRect(0, 0, canvas.width, canvas.height);
    dataURL = canvas.toDataURL('image/png');
  }

  //when you click 'take picture' button draw the image
  //and set the dataURL variable to be the image taken from the canvas
  //need to convert image to dataURI ////https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/toDataURL
  function takepicture() {
    var context = canvas.getContext('2d');
    if (width && height) {
      canvas.width = width;
      canvas.height = height;
      context.drawImage(video, 0, 0, width, height);
      dataURL = canvas.toDataURL('image/png');
      console.log(dataURL);
    } else {
      clearphoto();
      dataURL = ''; //clear data url
    }
  }

  console.log("client js for socket ex is loaded");
  //make a constant to hold where we will display all the images submitted
  const imgsContainer = document.getElementById("imgs");

  //select our input form thing:
  const selfieInput = document.getElementById('selfie');
  //clicking on the Submit button calls back the function upload_image()

  document.getElementById('submit-image').addEventListener("click", upload_image);

  // const userinput = document.querySelector('input');

  //set up the client socket to connect to the socket.io server
  //
  let clientSocket = io.connect('http://localhost:4200');
  //let theIds = [];
  clientSocket.on('connect', function(data) {
    console.log("connected");
    //whenever you get image data from the server,
    //handle the socket event: receivedFileData
    //receivedFileData, recieve image object with URL from server
    //happens when someone uploads an image and when someone connects to the socket
    clientSocket.on('receivedFileData', function(data) {
      console.log(data);
      let imgObj = JSON.parse(data);
      add_image(imgObj.url); //add our image to the website and display it!
    })

    clientSocket.on('disconnect', () => {
      console.log("disconnected");
    });
  });


  //upload_image()
  //create a constant to hold the object that holds the image that is uploaded to the input by the user
  //<input type="file">
  //converting base64 to blob
  function b64toBlob(b64Data, contentType, sliceSize) {
    contentType = contentType || '';
    sliceSize = sliceSize || 512;
    var byteCharacters = atob(b64Data); // window.atob(b64Data)
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    var blob = new Blob(byteArrays, {
      type: contentType
    });
    return blob;
  }

  //sending image to server
  function upload_image() {
    if (!dataURL) {
      return;
    }
    var form = document.getElementById("myAwesomeForm");
    var ImageURL = dataURL; // 'photo' is your base64 image
    // Split the base64 string in data and contentType
    var block = ImageURL.split(";");
    // Get the content type of the image
    var contentType = block[0].split(":")[1]; // In this case "image/gif"
    // get the real base64 content of the file
    var realData = block[1].split(",")[1];
    // Convert it to a blob to upload
    var blob = b64toBlob(realData, contentType);
    // Create a FormData and append the file with "image" as parameter name
    var formDataToUpload = new FormData(form);
    console.log(formDataToUpload);
    formDataToUpload.append("image", blob);
    // //SERVER STUFF
    // Now we can send the blob to a server...
    var serverUrl = "/upload";
    //we've made a POST endpoint on the server at /upload
    //build a HTTP POST request
    var request = new XMLHttpRequest();
    request.open("POST", serverUrl);
    request.onload = function(evt) {
      if (request.status == 200) {
        console.log("successful upload of image");
        //clear the file list
        // userinput.value = '';
        selfieInput.value = '';
        dataURL = '';
      } else {
        console.log("got error ", evt);
      }
    };
    request.send(formDataToUpload);
  };

  //function to add submitted image to beginng of imgsContainer
  function add_image(url) {
    let img = document.createElement("img");
    img.src = url;
    imgsContainer.prepend(img);
  }
}; //end window on load
