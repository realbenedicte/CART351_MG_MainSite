Sonic Sculpt - Application for CART 351
By Maxime Gordon

This web app borrows heavily from Matt Herero's grains4u application.
Please see his work here:
https://cm-gitlab.stanford.edu/mherrero/grains4u
